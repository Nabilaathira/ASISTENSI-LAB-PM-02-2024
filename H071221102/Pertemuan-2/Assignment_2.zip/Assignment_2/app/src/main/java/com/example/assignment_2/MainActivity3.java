package com.example.assignment_2;


import androidx.appcompat.app.AppCompatActivity;

import android.net.Uri;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity3 extends AppCompatActivity {

    private ImageView imageView2;

    private TextView textView3;

    private TextView textView4;

    private TextView titleTextView;

    private TextView contentTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);

        // Mengambil data dari Intent
        String imageUriString = getIntent().getStringExtra("imageUri");
        String userInput = getIntent().getStringExtra("userInput");
        String usernameInput = getIntent().getStringExtra("usernameInput");
        String title = getIntent().getStringExtra("title");
        String content = getIntent().getStringExtra("content");

        // Menampilkan data di TextView
        textView3 = findViewById(R.id.textView3);
        textView4 = findViewById(R.id.textView4);
        titleTextView = findViewById(R.id.titleTextView);
        contentTextView = findViewById(R.id.contentTextView);
        imageView2 = findViewById(R.id.imageView2);



        textView3.setText(userInput);
        textView4.setText(usernameInput);

        titleTextView.setText(title);
        contentTextView.setText(content);


        if (imageUriString != null) {
            Uri imageUri = Uri.parse(imageUriString);
            imageView2.setImageURI(imageUri);
        }
    }
}