package com.example.praktikum3;

import java.util.ArrayList;

public class DataSource {

    public static ArrayList<Anime> animeies = generateDummyAnimeies();

    private static ArrayList<Anime> generateDummyAnimeies() {
    ArrayList<Anime> animeies = new ArrayList<>();
        animeies.add(new Anime("Haikyuu", "Semangat Bertanding di Lapangan, Mimpi yang Menggairahkan!", R.drawable.haikyu, R.drawable.haikyu2, R.drawable.haikyu3,6000000, 1221));
        animeies.add(new Anime("Narutoo", "Mimpi yang Dikejar: Keberanian seorang Ninja.", R.drawable.naruto, R.drawable.naruto2, R.drawable.naruto3, 5000000, 1300));
        animeies.add(new Anime("One Piece", "Petualangan Tak Tergantikan: Mencari Harta Karun Legendaris.", R.drawable.op, R.drawable.op2, R.drawable.op3, 100000, 1100));
        animeies.add(new Anime("Solo Leveling", "Kekuatan Soliter, Ketinggian Tak Terbatas!", R.drawable.sl, R.drawable.sl3, R.drawable.sl2, 15000000, 13));
        animeies.add(new Anime("Tensei Slime ", " Mengarungi Dunia Baru, Reinkarnasi Penuh Petualangan!", R.drawable.rt, R.drawable.rt2, R.drawable.rt3, 5000000, 54));
        animeies.add(new Anime("Kuroko's Basketball", "Melemparkan Bayangan, Mewujudkan Impian di Lapangan!", R.drawable.kr, R.drawable.kr2, R.drawable.kr3, 5000000, 81));
        animeies.add(new Anime("Akuyaku level 99", "Mengarungi Dunia Fantasi, Kekuatan Tanpa Batas!", R.drawable.ak, R.drawable.ak2, R.drawable.ak3, 5000000, 91));
        animeies.add(new Anime("Dr.Stone", "Memecahkan Misteri Zaman Batu, Membangun Masa Depan Dengan Sains!", R.drawable.dr, R.drawable.dr2, R.drawable.dr3, 5000000, 881));
        animeies.add(new Anime("Classroom Elite", "Di Sekolah Elite, Intrik dan Ambisi Berpadu!", R.drawable.ce, R.drawable.ce2, R.drawable.ce3, 5000000, 881));
        animeies.add(new Anime("One Punch Man", "Kekuatan Satu Pukulan, Kehidupan Penuh Kepahlawanan!", R.drawable.opm, R.drawable.opm2, R.drawable.opm3, 5000000, 851));
    return animeies;
    }
}
